<!DOCTYPE html>
<html>

<head>
    <title>Game Splash Screen</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/animation.css">
</head>

<body>
    <div class="splash-screen">
        <img src="assets/img/logo.png" alt="Game Logo" class="logo">
        <p class="loading-text">Loading...</p>
    </div>
    <script src="assets/js/script.js"></script>
</body>

</html>